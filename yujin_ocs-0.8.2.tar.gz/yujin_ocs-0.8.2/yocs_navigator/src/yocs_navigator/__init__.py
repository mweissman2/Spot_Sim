'''
 yocs_navigator
 LICENSE : BSD - https://raw.github.com/yujinrobot/yujin_ocs/license/LICENSE
'''
from .basic_move_controller import BasicMoveController
