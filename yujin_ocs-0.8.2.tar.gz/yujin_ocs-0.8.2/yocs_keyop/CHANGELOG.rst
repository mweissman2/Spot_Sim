=========
Changelog
=========

0.6.4 (2015-10-10)
------------------
* dont block while waiting for connection

0.6.2 (2014-11-30)
------------------
* adds a little launcher restructing for muxer and smoother
* yocs_keyop: renames executable (fixes `#51 <https://github.com/yujinrobot/yujin_ocs/issues/51>`_)
* yocs_keyop: typo fix
* yocs_keyop: adds small updates
* adds yocs_keyop package
* Contributors: Marcus Liebhardt

* adds a little launcher restructing for muxer and smoother
* yocs_keyop: renames executable (fixes `#51 <https://github.com/yujinrobot/yujin_ocs/issues/51>`_)
* yocs_keyop: typo fix
* yocs_keyop: adds small updates
* adds yocs_keyop package
* Contributors: Marcus Liebhardt

0.6.1 (2014-07-08 11:21)
------------------------

0.6.0 (2014-07-08 11:07)
------------------------

0.5.3 (2014-03-24)
------------------

0.5.2 (2013-11-06)
------------------

0.5.1 (2013-10-14)
------------------

0.5.0 (2013-10-11 16:44)
------------------------

0.4.2 (2013-10-11 16:17)
------------------------

0.4.1 (2013-10-08)
------------------

0.4.0 (2013-09-23 11:17)
------------------------

0.3.0 (2013-07-02)
------------------

0.2.3 (2013-09-23 11:23)
------------------------

0.2.2 (2013-02-10)
------------------

0.2.1 (2013-02-08)
------------------

0.2.0 (2013-02-07)
------------------

0.1.3 (2013-01-08)
------------------

0.1.2 (2013-01-02)
------------------

0.1.1 (2012-12-21)
------------------

0.1.0 (2012-12-05)
------------------
