Changelog
=========

0.8.0 (2016-05-06)
------------------
* rotate : try to intelligently rotate out of problems
* honk and wait: moved from yujinrobot's custom navigation fork
